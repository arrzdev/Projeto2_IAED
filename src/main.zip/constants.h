#ifndef __CONSTANTS_H__
#define __CONSTANTS_H__

#define MAX_AIRPORT_ID_SIZE 3
#define MAX_COUNTRY_SIZE 30
#define MAX_CITY_SIZE 50
#define MAX_AIRPORTS 40
#define MAX_FLIGHTS 30000
#define MAX_FLIGHT_ID_SIZE 6

#endif